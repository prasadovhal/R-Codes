#Problem 11
f <- function(x)  #assigning f(x)
{
	return((1/sqrt(2*pi))*(exp((-1/2)*(x^2)))) 
}

simpson <- function(a,b,n)  #assigning function for integration
{
	x <- NULL
	y <- NULL
	h <- (b-a)/(n-1);
	x <- a+((1:n) - 1)*h     #calculation for x(i)
	y <- f(x) 		#calculatiok for f(x(i))

	yeven <- 0
	d <- 2	
	while(d < length(y))        #calculation sum of even terms
	{
		yeven <- yeven + y[d]
		d <- d+2		
	}

	yodd <- 0	
	e <- 3
	while(e < length(y))         #calculation sum of odd terms
	{	
		yodd <- yodd + y[e]
		e <- e+2
	}

	sum <- (h/3)*((y[1] + y[length(y)]) + (4*(yeven)) + (2*(yodd)))  #calculation for total Integration
	
	return(sum)
}

n <- c( 3, 11, 23, 31, 43, 53)
simp <- NULL                          #assigning matrix for integration values for each n 
c <- 1
for(i in n)

{
	simp[c] <- simpson(1,2,i)      #calling function for n[i] value and storing value in trap[c]
	c <- c+1
}

m <- integrate(f,1,2)          #exact integration
mnew<-m$value 			# selecting value of integraion from entire string
error<-(simp-mnew)/mnew		#error calculation 
p <- cbind( n, simp, error)	#final output	
format(p, digits = 17, scientific = T )
print(p)

