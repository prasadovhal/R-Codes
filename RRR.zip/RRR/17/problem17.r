pdf("problem17.pdf");
a=rnorm(100);
par(fig=c(0,0.8,0,0.8),new=TRUE);
hist(a);
par(fig=c(0,0.8,0.55,1),new=TRUE);
boxplot(a,horizontal=TRUE,axes=FALSE);
dev.off()
#this script I run at home(on windows system),I have problem while saving pdf using "pdf('name.pdf')".
So I save attached pdf by running script in R console,once output graph plotes 
I save it in .emf format & then convert .emf format in pdf.(I got that on net for windows system)