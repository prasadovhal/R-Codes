pdf("prob17.R")
x <- rnorm(100)
s <- layout(mat = matrix(c(1,2),2,1), height = c(1,3))  #layout setting and divind screen
par(mar = c(5.1, 4.1, 1.1, 2.1))			#combining plot
boxplot(x, horizontal = TRUE, axes = FALSE )		
hist(x, breaks = 10, col = "grey" )
dev.off()

