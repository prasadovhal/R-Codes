pdf('problem9.pdf')
N=c(10,10^2,10^3,10^4,10^5);
M=1000;
D1=c();D2=c();
for(i in 1:length(N))
        {
        t1=c();t2=c();T1=c();
        t3=c();t4=c();T2=c();
        for(j in 1:M)                
	        {
	        t1[j]=Sys.time()	        
	        x[j]=rnorm(N[i]);
	        mean(x[j])
	        t2[j]=Sys.time()
	        T1[j]=(t2[j]-t1[j])
	        }
	D1[i]=      	      
        for(k in 1:M)
                {
                t3[k]=Sys.time()
                x[k]=rnorm(N[i]);
                median(x[k])
                t4[k]=Sys.time()
                T2[k]=(t4-t3)
                }    
        }
boxplot(T1)
dev.off()
