#Problem 3
f <- function(x) #assigning f(x)
{
	return((1/sqrt(2*pi))*(exp((-1/2)*(x^2))))
}

trapezoidal <- function(a,b,n)  #assigning function for integration
{
	x <- NULL
	y <- NULL
	h <- (b-a)/(n-1)
	x <- a+((1:n) - 1)*h    #calculation for x(i)
	y <- f(x)		#calculatiok for f(x(i))		

	sum <- h*(0.5*(y[1] + y[length(y)]) + sum(y[-c(1,length(y))]))     #calculation for total Integration
	
	return(sum)
}

n <- c(2,11,20,31,40,51)
trap <- NULL            #assigning matrix for integration values for each n 
c <- 1
for(i in n)
{
	trap[c] <- trapezoidal(1,2,i)    #calling function for n[i] value and storing value in trap[c] 
 	c <- c+1
}
m <- integrate(f,1,2)    #exact integration
mnew<-m$value		# selecting value of integraion from entire string
error<-(trap-mnew)/mnew #error calculation 
p <- cbind(n,trap,error) #final output
format(p, digits = 17, scientific = T) 
print(p)
