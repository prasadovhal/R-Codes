pdf('problem6.pdf')
plot.new();
plot.window(xlim=c(-1,1),ylim=c(-1,1),asp=1);
axis(1);
axis(2);
axis(3);
axis(4);
x0=rep(-1,20);
y0=seq(-1,1,0.1);
x1=seq(-1,1,0.1);
y1=rep(1,20);
segments(x0,y0,x1,y1)
x0=rep(1,20);
y0=seq(-1,1,0.1);
x1=seq(-1,1,0.1);
y1=rep(-1,20);
segments(x0,y0,x1,y1)
dev.off()
#this script I run at home(on windows system),I have problem while saving pdf using "pdf('name.pdf')".
#So I save attached pdf by running script in R console,once output graph plotes 
#I save it in .emf format & then convert .emf format in pdf.(I got that on net for windows system)
