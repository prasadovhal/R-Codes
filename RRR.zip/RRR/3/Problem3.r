a=1;
b=2;
n=c(2,11,20,31,40,51);
h=[ ]; I=[];Int=[];
for(i in 1:length(n))
{h[i]=(b-a)/(n[i]-1)
 p=0;
 for(j in 1:length(h))
 {x[j]=[ ] ; y[j]=[ ] ;
  for (k in 1:n)
  {p=(p+1);x(k)=a+(p-1)*h[ j ];y(k)=exp(-(0.5*(x(k))^2))}
   L=length(x);
   Int[j]=h[j]*(2*(y[1]+y[L])+sum(y)-y[1]-y[L]);
   }
   I=(1/sqrt(2*pi)*Int
 }
#Iexact=
#data.frame(as.table(setNames(n,I,Relative Error)))
