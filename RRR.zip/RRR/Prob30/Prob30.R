x<-iris[1:4]   #assigning pair of 4 variable from iris
plot(x)		#pairplot
boxplot(x)	#boxplot 
y<- iris[2:3]   #assigning pair of second and third variable
plot(y, pch=20, col =c("red", "blue", "green"))  #scatterplot of two variable
