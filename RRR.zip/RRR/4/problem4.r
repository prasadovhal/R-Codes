a=seq(-1,1,by=0.01)
b=seq(1,-1,by=0.01)
plot(a,b)
