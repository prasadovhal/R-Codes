pdf("problem16.pdf")
n=seq(2,25,1);
f=c(0,1);
for(i in n)
{
f[i+1]=f[i]+f[i-1];
}
print(f);
CGR=c();           #Calculated Golden Ratio
RE=c();            # Relative Error
EGR=((1+sqrt(5))/2); #Exact Golden Ratio
EGR1=sprintf("%.16f",EGR); #with 16 digit accuruccy
for(j in 2:length(n))
{
CGR[j]=(f[j+1]/f[j]);
RE[j]=(abs(CGR[j]-EGR)/EGR);       
}
RE1=sprintf("%.16f",RE);  #with 16 digit accuruccy
par(mfrow=c(2,1));
plot(n,CGR,type="b",xlab="n",ylab="CGR=f(n)/f(n-1)");
abline(h=EGR1,lty=2,col="red");
plot(n,RE1,type="b",xlab="n",ylab="RE=|(CGR-EGR)/EGR|");
#print(EGR);
#print(CGR);
#print(RE);
#print(EGR1);
#print(RE1);
dev.off()
#this script I run at home(on window),I have problem while saving pdf using pdf().
So I save attached pdf by running script in R console,once output graph plotes 
I save it in .emf format & then convert .emf format in pdf.
