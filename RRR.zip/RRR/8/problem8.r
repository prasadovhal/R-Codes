pdf('problem8.pdf')
N=c(10,10^2,10^3,10^4,10^5);
M=1000;
Timediff1=c();Timediff2=c();
for(i in 1:length(N))
        {
        t1=c();t2=c();T1=c();
        t3=c();t4=c();T2=c();
        for(j in 1:M)                
	        {
	        t1[j]=Sys.time()	        
	        a=runif(N[i]);
	        mean(a)
	        t2[j]=Sys.time()
	        T1[j]=(t2[j]-t1[j])
	        }
	Timediff1[i]=sum(T1)/M;       	      
        for(k in 1:M)
                {
                t3[k]=Sys.time()
                b=runif(N[i]);
                median(b)
                t4[k]=Sys.time()
                T2[k]=(t4-t3)
                }
        Timediff2[i]=sum(T2)/M;        
        }
#print(Timediff1)
#print(Timediff2)
plot(N,Timediff1,type="b",log="x",col="red")
lines(N,Timediff2,type="b",log="x",col="green")
dev.off()
