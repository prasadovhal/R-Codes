#problem 5
pdf("probfifth.r")
x <- rnorm(100)   
par(mfrow=c(2,2))  #defing screen in 2 row and 2 column
hist(x, freq= FALSE, breaks=10, col="grey", main="Histogram of x")
rug(x, col="black")
lines(density(x), lwd=1)  #density kernel
plot(ecdf(x))	
acf(x, type ="correlation", plot = TRUE)
qqnorm(x)
qqline(x)
dev.off()

