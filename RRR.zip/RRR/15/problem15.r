pdf('problem15.pdf')
n=c(10,100,1000,10000,100000);
I1=matrix(c(0),nrow=1000,ncol=length(n));
I2=matrix(c(0),nrow=1000,ncol=length(n));
for(i in 1:length(n))
        {
        
        for (j in 1:1000)
                {
                u=runif(n[i],0,1);
                f1=(1-u);
                f2=sqrt((1-u^2));
                I1[j,i]=sum(f1)/n[i];
                I2[j,i]=sum(f2)/n[i]
                }
        }
#print(I1)
#print(I2)
par(mfrow=c(2,1))
boxplot(I1,xlab="N",ylab="Estimated Integral-f1")
abline(h=0.5,lty=2,col="red")
boxplot(I2,xlab="N",ylab="Estimated Integral-f2")
abline(h=pi/4,lty=2,col="red")
dev.off()                     
#this script I run at home(on windows system),I have problem while saving pdf using "pdf('name.pdf')".
So I save attached pdf by running script in R console,once output graph plotes 
I save it in .emf format & then convert .emf format in pdf.(I got that on net for windows system)